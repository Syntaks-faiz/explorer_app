import { Elysia } from 'elysia'
import { cors } from '@elysiajs/cors'
import postgres from 'postgres'

const sql = postgres({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 5432),
  database: process.env.DB_NAME || 'explorer',
  username: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASS || 'devpass'
})

function buildTree(folders: Array<{ id: number; name: string; parent_id: number | null }>) {
  const map = new Map<number, any>()
  const roots: any[] = []
  for (const f of folders) map.set(f.id, { id: f.id, name: f.name, parent_id: f.parent_id, children: [] })
  for (const item of map.values()) {
    if (item.parent_id == null) roots.push(item)
    else {
      const parent = map.get(item.parent_id)
      if (parent) parent.children.push(item)
    }
  }
  return roots
}

const app = new Elysia()

app.use(cors({ origin: '*' }))

app.get('/api/folders/tree', async () => {
  const folders = await sql`SELECT id, name, parent_id FROM folders ORDER BY id`
  return buildTree(folders)
})

app.get('/api/folders/:id/children', async ({ params }) => {
  const folderId = Number(params.id)
  const subfolders = await sql`SELECT id, name FROM folders WHERE parent_id = ${folderId} ORDER BY name`
  const files = await sql`SELECT id, name, size, mime FROM files WHERE folder_id = ${folderId} ORDER BY name`
  return { subfolders, files }
})

app.get('/api/root/children', async () => {
  const root = await sql`SELECT id FROM folders WHERE parent_id IS NULL LIMIT 1`
  if (!root.length) return { subfolders: [], files: [] }
  const id = root[0].id
  const subfolders = await sql`SELECT id, name FROM folders WHERE parent_id = ${id} ORDER BY name`
  const files = await sql`SELECT id, name, size, mime FROM files WHERE folder_id = ${id} ORDER BY name`
  return { rootId: id, subfolders, files }
})

app.listen(3000)
console.log('Backend listening at http://localhost:3000')
