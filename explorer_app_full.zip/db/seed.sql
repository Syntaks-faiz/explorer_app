INSERT INTO folders (name, parent_id) VALUES ('root', NULL); -- id = 1
INSERT INTO folders (name, parent_id) VALUES ('Documents', 1);
INSERT INTO folders (name, parent_id) VALUES ('Photos', 1);
INSERT INTO folders (name, parent_id) VALUES ('Work', 2);
INSERT INTO folders (name, parent_id) VALUES ('Personal', 2);

INSERT INTO files (folder_id, name, size, mime) VALUES
(2, 'resume.pdf', 34567, 'application/pdf'),
(3, 'vacation.jpg', 456789, 'image/jpeg'),
(4, 'project-plan.docx', 23456, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
