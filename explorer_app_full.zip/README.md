# Explorer App - Full Skeleton
Stack:
- Backend: Bun + Elysia (TypeScript)
- Database: PostgreSQL
- Frontend: Vue 3 + Vite (TypeScript)

Quick run (Windows / PowerShell):
1. Start Postgres (or run via Docker):
   docker run --name pg-dev -e POSTGRES_PASSWORD=devpass -e POSTGRES_DB=explorer -p 5432:5432 -d postgres:15
2. Apply DB schema & seed:
   psql -h localhost -U postgres -d explorer -f db/create_tables.sql
   psql -h localhost -U postgres -d explorer -f db/seed.sql
3. Backend:
   cd backend
   bun install
   bun run start
4. Frontend:
   cd frontend
   bun install
   bun run dev

Open: http://localhost:5173
