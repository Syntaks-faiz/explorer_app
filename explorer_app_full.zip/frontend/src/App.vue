<template>
  <div class="app">
    <div class="left">
      <FolderTree @select="onSelect" />
    </div>
    <div class="right">
      <RightPanel :folderId="selectedFolderId" @select="onSelect" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import FolderTree from './components/FolderTree.vue'
import RightPanel from './components/RightPanel.vue'

const selectedFolderId = ref<number | null>(null)
function onSelect(id: number) {
  selectedFolderId.value = id
}
</script>

<style>
.app { display:flex; height:100vh; }
.left { width: 320px; border-right:1px solid #ddd; overflow:auto; }
.right { flex:1; padding:16px; overflow:auto; }
</style>
