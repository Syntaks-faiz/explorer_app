<template>
  <li>
    <div class="node-line">
      <button v-if="hasChildren" @click="toggle" class="toggle-btn">{{ open ? '-' : '+' }}</button>
      <span @click="emitSelect" class="node-name">{{ node.name }}</span>
    </div>
    <ul v-show="open" v-if="hasChildren">
      <TreeNode v-for="c in node.children" :key="c.id" :node="c" @select="$emit('select', $event)" />
    </ul>
  </li>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import type { PropType } from 'vue'
import TreeNode from './TreeNode.vue'

const props = defineProps({ node: { type: Object as PropType<any>, required: true } })
const emit = defineEmits(['select'])
const open = ref(false)
const hasChildren = props.node.children && props.node.children.length > 0

function toggle() { open.value = !open.value }
function emitSelect() { emit('select', props.node.id) }
</script>

<style>
.node-line { display:flex; align-items:center; gap:8px; padding:4px 8px; }
.node-name { cursor:pointer; }
ul { list-style:none; padding-left:18px; margin:0; }
.toggle-btn { width:24px; height:24px; }
</style>
