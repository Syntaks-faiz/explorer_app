<template>
  <div>
    <h3>Folder contents</h3>
    <div v-if="loading">Loading...</div>
    <div v-else>
      <h4>Folders</h4>
      <ul>
        <li v-for="f in data.subfolders" :key="f.id" @click="selectFolder(f.id)" style="cursor:pointer">{{ f.name }}</li>
      </ul>
      <h4>Files</h4>
      <ul>
        <li v-for="file in data.files" :key="file.id">{{ file.name }} ({{ file.size }} bytes)</li>
      </ul>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
const props = defineProps<{ folderId: number | null }>()
const emit = defineEmits(['select'])

const data = ref({ subfolders: [], files: [] })
const loading = ref(false)

async function load(id: number | null) {
  loading.value = true
  try {
    if (id == null) {
      const res = await fetch('http://localhost:3000/api/root/children')
      data.value = await res.json()
    } else {
      const res = await fetch(`http://localhost:3000/api/folders/${id}/children`)
      data.value = await res.json()
    }
  } catch (e) {
    console.error(e)
  } finally {
    loading.value = false
  }
}

watch(() => props.folderId, (v) => load(v), { immediate: true })

function selectFolder(id: number) { emit('select', id) }
</script>
