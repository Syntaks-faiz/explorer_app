<template>
  <div>
    <ul class="tree-root">
      <TreeNode v-for="n in tree" :key="n.id" :node="n" @select="emitSelect" />
    </ul>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import TreeNode from './TreeNode.vue'

const tree = ref<any[]>([])

async function load() {
  try {
    const res = await fetch('http://localhost:3000/api/folders/tree')
    tree.value = await res.json()
  } catch (e) {
    console.error(e)
  }
}

onMounted(load)
const emit = defineEmits(['select'])
function emitSelect(id: number) { emit('select', id) }
</script>

<style>
ul { list-style:none; padding-left:8px; }
</style>
